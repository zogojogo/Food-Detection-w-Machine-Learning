
Food - v1 2021-05-25 2:36pm
==============================

This dataset was exported via roboflow.ai on May 25, 2021 at 7:37 AM GMT

It includes 2484 images.
Pieces are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


